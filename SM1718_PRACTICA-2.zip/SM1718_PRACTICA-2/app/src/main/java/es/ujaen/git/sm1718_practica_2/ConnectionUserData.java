package es.ujaen.git.sm1718_practica_2;

/**
 * Created by usuario on 04/10/2017.
 */

public class ConnectionUserData extends PersonalData {
    //Variables
    protected String connectionIp="127.0.0.1";
    protected short connectionPort=80;


    //Constructor
    public ConnectionUserData(String user,String pass, String DNI, String correo, String ip,short port){
        //Llamada al constructor de la clase padre para utilizar los parámetros anteriores
        super(user,pass, DNI, correo);
        this.connectionIp=ip;
        this.connectionPort=port;
    }
    public ConnectionUserData(String user, String pass, String DNI, String correo){
        //Llamada al constructor de la clase padre para utilizar los parámetros anteriores
        super(user,pass, DNI, correo);
    }

    public short getConnectionPort() {
        return connectionPort;
    }

    public void setConnectionPort(short connectionPort) {
        this.connectionPort = connectionPort;
    }

    public String getConnectionIp() {
        return connectionIp;
    }

    public void setConnectionIp(String connectionIp) {
        this.connectionIp = connectionIp;
    }
}
