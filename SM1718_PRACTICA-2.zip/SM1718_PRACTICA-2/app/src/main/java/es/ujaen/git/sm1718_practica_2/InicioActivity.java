package es.ujaen.git.sm1718_practica_2;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class InicioActivity extends AppCompatActivity {

    //Creamos instancia de una actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //Cambiar launcher de activity_main del manifest a un launcher de activity
        //Mostramos el layout inicio_app
        setContentView(R.layout.inicio_app);
        //Antes de autentificar la interfaz de usuario, comprobamos si se está recreando una instancia
        // previamente destruida
        if (savedInstanceState != null) {
        }

    }

    //Introducimos un método con onIcon
    //Este metodo nos mostrará el activity_main cuando el icono es pulsado
    //En las propiedades inicio_app en el método onclick debemos llamar a este método
    public void onIcon2(View vista){
        //Declaramos una variable nueva de tipo intent
        //intent sirve para invocar o pasar a otras actividades

        Intent nueva = new Intent(getApplicationContext(), MainActivity.class); //-> intent (contexto, segunda actividad a la que pasamos)

        //Iniciamos la actividad
        startActivity(nueva);
    }
}

