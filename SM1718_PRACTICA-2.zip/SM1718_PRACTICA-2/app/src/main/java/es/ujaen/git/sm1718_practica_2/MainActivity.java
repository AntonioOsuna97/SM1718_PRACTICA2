package es.ujaen.git.sm1718_practica_2;


import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {

    //Crea una instancia de una actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Bundle savedInstanceState es donde se reciben los datos almacenados tras un recreado de la actividad
        super.onCreate(savedInstanceState); // Siempre llamar a la superclase primero
        //Mostramos el siguiente layout
        setContentView(R.layout.activity_main);




        SharedPreferences prefs = getSharedPreferences("MisPreferencias", Context.MODE_WORLD_READABLE);
        String expires=prefs.getString("expires","");



        if(expires.length()!=0) {
            //Obtenenemos la hora y la fecha para poder comparar
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat dateFormat2 = new SimpleDateFormat("HH-mm-ss", Locale.getDefault());
            Date date = new Date();

            String fecha = dateFormat.format(date);
            String hora = dateFormat2.format(date);
            final String Conjunto = fecha + "-" + hora;

            /*
            * El método compareTo se usa para comparar dos cadenas, indicando que cadena es mayor.
            * Nos puede devolver:
            * Número positivo: la cadena 1 es mayor que la cadena 2.
            * 0: las cadenas son iguales.
            * Número negativo: la cadena 1 es menor que la cadena 2.
            * */

            //La hora que nos muestra la cadena conjunto es 24h, mientras que el expires es 12h. Por lo tanto,
            //Si se realizan pruebas por la tarde siempre el tiempo de expiracion será superado
            if (Conjunto.compareTo(expires) > 0) {
                //Si la cadena Conjunto es mayor que expires, tiempo expirado
                Toast.makeText(getApplicationContext(), "¡Tiempo de expiración superado!", Toast.LENGTH_LONG).show();
                //FuncionBack();

            } else {


                LoginFragment.TareaAutentica tarea = new LoginFragment.TareaAutentica(this);
                ConnectionUserData data = new ConnectionUserData(prefs.getString("usuario",""), prefs.getString("password",""), prefs.getString("DNI",""), prefs.getString("correo",""));

                tarea.execute(data);
            }
        }
        //Creamos el Timer
//        Timer timer = new Timer();
        //Que actue cada 10000 milisegundos
        //Empezando desde el segundo 0
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                //La función que queremos ejecutar
//                TiempoExpiracion();
//            }
//
//            private void TiempoExpiracion() {
//                //Esta función es llamada desde dentro del Timer
//                //Para no provocar errores ejecutamos la función tiempo
//                //Dentro del mismo Hilo
//
//
//                if(Conjunto.compareTo(prefs.)){
//
//                    Toast.makeText(getApplicationContext(), "Tiempo de expiración superado!", Toast.LENGTH_LONG).show();
//                    // FuncionBack();
//
//                }else{
//
//                }
//            }
//
//        },0,10000);



        //Antes de autentificar la interfaz de usuario, comprobamos si se está recreando una instancia
        // previamente destruida
        if(savedInstanceState!=null){
        }

    }



    ///Metodo que guarda el estado
    @Override
    protected void  onSaveInstanceState(Bundle outState) {
        // Siempre se debe llamar a la superclase para guardar el estado de la jerarquía de vistas
        super.onSaveInstanceState(outState);
    }


}
