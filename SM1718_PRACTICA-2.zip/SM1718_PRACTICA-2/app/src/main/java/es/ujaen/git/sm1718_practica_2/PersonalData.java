package es.ujaen.git.sm1718_practica_2;

/**
 * Created by usuario on 04/10/2017.
 */

//Clase de datos personales
public class PersonalData {
    protected String name="";
    protected String DNI="";
    protected String correo="";
    protected String user="";
    protected String pass="";
    //Constructor para inicializar el usuario, la clave, DNI y correo
    public PersonalData(String user, String pass, String DNI, String correo){
        //Coge este objeto y asígnale el valor pasado a la entrada del constructor
        this.user=user;
        this.pass=pass;
        this.correo=correo;
        this.DNI=DNI;

    }



    //constructor por defecto
    public PersonalData(){

    }

    //Creamos los metodos get y set de las clases protegidas y privadas
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
