package es.ujaen.git.sm1718_practica_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;





public class ServiceActivity extends AppCompatActivity {
    //Static final indica que una variable, método o clase no se va a modificar
    public static final String PARAM_USER = "param_user";
    public static final String PARAM_PASS = "param_pass";
    public static final String PARAM_CORREO = "param_correo";
    public static final String PARAM_DNI = "param_dni";
    public static final String PARAM_PORT = "param_port";
    public static final String PARAM_EXPIRES = "param_expires";



    //No la necesitamos
    public void FuncionBack(){
        this.finish();
    }



    //Creamos una instancia de una actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Bundle savedInstanceState es donde se reciben los datos almacenados tras un recreado de la actividad
        super.onCreate(savedInstanceState); // Siempre llamar a la superclase primero
        //Mostramos el fragmento activity_service
        setContentView(R.layout.activity_service);


        //getIntent() Deuelve la intencion que inició la actividad
        String user = getIntent().getStringExtra(PARAM_USER);
        String pass = getIntent().getStringExtra(PARAM_PASS);
        String correo = getIntent().getStringExtra(PARAM_CORREO);
        short port = getIntent().getShortExtra(PARAM_PORT, (short) 80);
        final String expires = getIntent().getStringExtra(PARAM_EXPIRES);



    }





    //Metodo que guarda el estado
    @Override
    protected void  onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }
}
