package es.ujaen.git.sm1718_practica_2;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;




/**
 * Aquí se hace la peticion http, ver seminario de socket en java
 * Para tener copia en github se hace un fork
 */

public class LoginFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    //Necesitamos definir las preferencias compartidas
    public static SharedPreferences prefs;


    // TODO: Rename and change types of parameters
    private String ip;
    private int port;

    //constructor vacio
    public LoginFragment() {
    }

    // TODO: Rename and change types and number of parameters
    public static LoginFragment newInstance(String ip, int port) {
        LoginFragment fragment = new LoginFragment();//se crea un objeto
        Bundle args = new Bundle();//se crea paquete
        args.putString(ARG_PARAM1, ip);//se mete una cadena,arg param es una constante
        args.putInt(ARG_PARAM2, port);//args.putInt se usaria para meter un entero
        fragment.setArguments(args);
        return fragment;
    }

    //Método que crea la instancia
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            ip = getArguments().getString(ARG_PARAM1);//guardo en una variable de entrada
            port = getArguments().getInt(ARG_PARAM2);// si fuera int se cambiaria a getInt()
        }

    }

    //metodo que crea la vista
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Con inflate dibuja el layout
        View fragment = inflater.inflate(R.layout.fragment_login, container, false);
        //Quiero tener acceso a un objeto boton
        //Hacemos un casting para el boton
        Button connect = (Button) fragment.findViewById(R.id.button);
        //Referencias edidText, en las cuales se escribe los distintos parametros
        final EditText pass = (EditText) fragment.findViewById(R.id.editText_login_pass);//donde esta usuario, se declara final porque no se va a modificar
        final EditText correo = (EditText) fragment.findViewById(R.id.editText_login_correo);
        final EditText DNI = (EditText) fragment.findViewById(R.id.editText_login_dni);
        final EditText user = (EditText) fragment.findViewById(R.id.editText_login_user);

        //Realizamos un escuchador para vincular un evento a un boton
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_user = user.getText().toString();
                String s_dni = DNI.getText().toString();
                String s_pass = pass.getText().toString();
                String s_correo = correo.getText().toString();
                String ip= "www4.ujaen.es";
                short port2 = 80;

                //Creamos un objeto llamado data de tipo conectionUserData
                ConnectionUserData data = new ConnectionUserData(s_user, s_pass, s_dni, s_correo, ip, port2);

                TareaAutentica tarea = new TareaAutentica(getActivity());
                //Autenticación correcta

                tarea.execute(data);//Creamos tarea
                //Nos muestra un mensaje con: "Bienvenido + el usuario"
                Toast.makeText(getContext(), "Bienvenido " + s_user, Toast.LENGTH_LONG).show();

            }
        });
        return fragment;//dibuja el layout
    }

    //metodo que crea la vista de inicio
    public View onCreateView2(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Con inflate dibuja el layout
        View fragment = inflater.inflate(R.layout.inicio_app, container, false);

        return fragment;//dibuja el layout
    }


    //Introducir permisos en el manifest de internet
    public static class TareaAutentica extends AsyncTask<ConnectionUserData, Void, String> {
        private ConnectionUserData data;
        private String line;
        private boolean error = false;
        private String sesionData[];
        private String expiresData[];

        private Context mContext=null;

        public TareaAutentica(Context context){
            mContext=context;
        }

        //Aquí es donde esta la autenticación
        public String doInBackground(ConnectionUserData... param) {//... param puede ser uno o varios paraametros de ese tipo
            // Si hay + de 1 parm. data=param
            //Petición http
            try {
                data = param[0];
                String s_user = data.user;
                String s_pass = data.pass;
                InetAddress address = InetAddress.getByName("www4.ujaen.es");
                Socket client = new Socket(address,80);
                BufferedReader input = new BufferedReader(new InputStreamReader(client.getInputStream()));
                DataOutputStream output = new DataOutputStream(client.getOutputStream());
                String get = "GET /~jccuevas/ssmm/autentica.php?user="+ s_user+ "&pass="+ s_pass+ "\r\n HTTP/1.1\r\n \r\n";
                output.write(get.getBytes());

                line=input.readLine();
                if(line!=null){
                    //Si la línea empieza por Sesio-ID
                    if (line.startsWith("SESION-ID=")) {
                        //Divide la linea por donde esté &
                        String params[] = line.split("&");
                        //Si el tamaño es 2
                        if (params.length == 2) {
                            sesionData = params[0].split("=");
                            expiresData = params[1].split("=");
                            //Log.d depura
                            Log.d("SesionID=", sesionData[1]);
                            Log.d("expireData", expiresData[1]);
                            if (sesionData.length == 2 && expiresData.length == 2)
                                error = false;
                        }
                    }

                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (param != null) {
                if (param.length >= 1)
                    data = param[0];
            }

            //Todo proceso auntentificacion
            return "OK";

        }


        //Método que inicia la actividad
        public void onPostExecute(String result) {

            //Poner las preferencias compartidas aquí.
            if (result.compareToIgnoreCase("OK") == 0) {
                //Pasamos a la actividad Service
                Intent nueva = new Intent(mContext, ServiceActivity.class);
                //Introducimos los datos
                nueva.putExtra(ServiceActivity.PARAM_USER, data.getUser());
                nueva.putExtra(ServiceActivity.PARAM_PASS, data.getPass());
                nueva.putExtra(ServiceActivity.PARAM_CORREO, data.getCorreo());
                nueva.putExtra(ServiceActivity.PARAM_DNI, data.getDNI());
                nueva.putExtra("param_expires", expiresData[1]);


                //Preferencias compartidas
                SharedPreferences prefs = mContext.getSharedPreferences("MisPreferencias", Context.MODE_WORLD_READABLE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("usuario", data.getUser());
                editor.putString("password", data.getPass());
                editor.putString("correo", data.getCorreo());
                editor.putString("DNI", data.getDNI());
                editor.putString("sesion ID", sesionData[1]);
                editor.putString("expires", expiresData[1]);
                editor.commit();

                //Empieza la actividad y puede leer los parámetros
                mContext.startActivity(nueva);
            } else {
                //Si no, nos muestra un error
                Toast.makeText(mContext, "Error auntentificando a " + data.getUser(), Toast.LENGTH_SHORT).show();
            }

        }
    }
}




